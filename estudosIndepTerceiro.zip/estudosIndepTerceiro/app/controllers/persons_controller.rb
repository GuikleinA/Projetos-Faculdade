class PersonsController < ApplicationController
  before_action :set_person, only: [:show, :update, :destroy]

  # GET /persons
  def index
    people = Person.all
    render json: people
  end

  # GET /persons/:id
  def show
    render json: @person
  end

  # POST /persons
  def create
    person = Person.new(person_params)
    if person.save
      render json: person, status: :created
    else
      render json: { errors: person.errors.full_messages }, status: :unprocessable_entity
    end
  end

  # PUT /persons/:id
  def update
    if @person.update(person_params)
      render json: @person
    else
      render json: { errors: @person.errors.full_messages }, status: :unprocessable_entity
    end
  end

  # DELETE /persons/:id
  def destroy
    @person.destroy
    head :no_content
  end

  private

    def set_person
      @person = Person.find_by(id: params[:id])
      return render json: { error: "Person not found" }, status: :not_found unless @person
    end

    def person_params
      params.require(:person).permit(:name, :email, :sexo, :city, :cpf)
    end
end
