class Person < ApplicationRecord
    
end
