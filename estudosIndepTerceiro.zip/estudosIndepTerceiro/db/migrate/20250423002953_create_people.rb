class CreatePeople < ActiveRecord::Migration[8.0]
  def change
    create_table :people do |t|
      t.string :name
      t.boolean :sexo
      t.string :city
      t.string :cpf
      t.string :email

      t.timestamps
    end
  end
end
